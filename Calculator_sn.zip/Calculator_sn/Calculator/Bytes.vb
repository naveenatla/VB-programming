﻿Public Class Bytes
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim CB1 As String
        Dim CB2 As String
        Dim Bt As String = ("Bytes")
        Dim MB As String = ("MB")
        Dim MB2 As Double
        CB1 = ComboBox1.SelectedItem
        CB2 = ComboBox2.SelectedItem

        If CB1 = "Bytes" And CB2 = "KB" Then
            MB2 = Me.TextBox1.Text / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "KB" And CB2 = "MB" Then
            MB2 = Me.TextBox1.Text / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "MB" And CB2 = "GB" Then
            MB2 = Me.TextBox1.Text / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "GB" And CB2 = "TB" Then
            MB2 = Me.TextBox1.Text / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "Bytes" And CB2 = "MB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "Bytes" And CB2 = "GB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "Bytes" And CB2 = "TB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024 / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "KB" And CB2 = "GB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "KB" And CB2 = "TB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "MB" And CB2 = "TB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "KB" And CB2 = "TB" Then
            MB2 = Me.TextBox1.Text / 1024 / 1024 / 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "KB" And CB2 = "Bytes" Then
            MB2 = Me.TextBox1.Text * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "MB" And CB2 = "KB" Then
            MB2 = Me.TextBox1.Text * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "GB" And CB2 = "MB" Then
            MB2 = Me.TextBox1.Text * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "TB" And CB2 = "GB" Then
            MB2 = Me.TextBox1.Text * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "GB" And CB2 = "MB" Then
            MB2 = Me.TextBox1.Text * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "MB" And CB2 = "Bytes" Then
            MB2 = Me.TextBox1.Text * 1024 * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "GB" And CB2 = "Bytes" Then
            MB2 = Me.TextBox1.Text * 1024 * 1024 * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "TB" And CB2 = "Bytes" Then
            MB2 = Me.TextBox1.Text * 1024 * 1024 * 1024 * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "GB" And CB2 = "KB" Then
            MB2 = Me.TextBox1.Text * 1024 * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "TB" And CB2 = "KB" Then
            MB2 = Me.TextBox1.Text * 1024 * 1024 * 1024
            Me.TextBox2.Text = MB2

        ElseIf CB1 = "TB" And CB2 = "MB" Then
            MB2 = Me.TextBox1.Text * 1024 * 1024
            Me.TextBox2.Text = MB2
        End If
    End Sub
End Class