﻿Public Class Calculator
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        My.Forms.Numeric.MdiParent = Me
        My.Forms.Numeric.Show()
    End Sub
    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        My.Forms.Bytes.MdiParent = Me
        My.Forms.Bytes.Show()
    End Sub
    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        My.Forms.Date1.MdiParent = Me
        My.Forms.Date1.Show()
    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles ToolStripButton4.Click
        Application.Exit()
    End Sub
End Class