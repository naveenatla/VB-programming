﻿Public Class Date1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim y, m, d, y1, m1, d1 As Integer
        y = Me.TextBox1.Text
        m = Me.TextBox2.Text
        d = Me.TextBox3.Text
        y1 = Me.TextBox4.Text
        m1 = Me.TextBox5.Text
        d1 = Me.TextBox6.Text

        If d1 < d Then
            m1 = m1 - 1
            d1 = d1 + 30
            d1 = d1 - d
        Else
            d1 = d1 - d
        End If

        If m1 < m Then
            y1 = y1 - 1
            m1 = m1 + 12
            m1 = m1 - m
        Else
            m1 = m1 - m
        End If

        If y1 > y Then
            y1 = y1 - y
        End If

        Me.Label9.Text = y1
        Me.Label10.Text = m1
        Me.Label11.Text = d1
    End Sub


End Class